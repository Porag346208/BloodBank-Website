<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
  font-family: Li Ador Noirrit;

   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: white;
   color: black;
   text-align: center;
   margin-top: 10px;
   padding: 5px 0px 5px 0px;
}
</style>
</head>
<body>

<div class="footer">
  <p><span id="demo"></span> <span class="brand">বাংলাদেশ ব্লাড ব্যাংক </span> © কপিরাইট ২০২৩
</footer></p>
</div>

</body>
</html> 